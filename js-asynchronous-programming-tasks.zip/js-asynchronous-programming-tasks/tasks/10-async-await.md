# Async/Await

Реализуйте и экспортируйте асинхронную функцию `exchange()`, которая обменивает содержимое двух файлов.

```js
import { exchange } from '../solutions/10-async-await.js';
 
exchange('/myfile1', '/myfile2');
```
