import fs from 'fs';

// BEGIN
export default function Func(path) {
    fs.readFile(path, 'utf-8', (_error, data) => {console.log(data);});
}
// END
