import fs from 'fs';

// BEGIN
export const compareFileSizes = (filepath1, filepath2, callback) => {
  fs.stat(filepath1, (_err1, stats1) => {
    fs.stat(filepath2, (_err2, stats2) => {
      const sizeComparison = Math.sign(stats1.size - stats2.size);
      callback(null, sizeComparison);
    });
  });
};
// END