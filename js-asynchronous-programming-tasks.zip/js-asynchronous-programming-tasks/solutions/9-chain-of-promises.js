import fsp from 'fs/promises';

// BEGIN
export const getTypes = (paths) =>
  Promise.all(paths.map(path =>
    fsp.stat(path)
      .then(stats => stats.isDirectory() ? 'directory' : 'file')
      .catch(err => null)
  ));
// END