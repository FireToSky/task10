import fs from 'fs';

// BEGIN
export const move = (Path1, Path2, callback) => {
    fs.readFile(Path1, 'utf-8', (err1, data) => {
        if (err1) {
            callback(err1);
            return;
        }
        fs.writeFile(Path2, data, (err2) => {
            if (err2) {
                callback(err2);
                return;
            }
            fs.unlink(Path1, (err3) => {
                if (err3) {
                    callback(err3);
                    return;
                }
                callback(null);
            })
        })
    })
}
// END
