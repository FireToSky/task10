import fs from 'fs';

// BEGIN
export default function watch (filepath, delay, callback) {
    let lastModifiedTime = Date.now();
  
    const checkFile = () => {
      fs.stat(filepath, (err, stats) => {
        if (err) {
          clearInterval(timerId);
          callback(err);
          return;
        }
  
        const currentModifiedTime = stats.mtimeMs;
        if (currentModifiedTime > lastModifiedTime) {
          lastModifiedTime = currentModifiedTime;
          callback(null);
        }
      });
    };
  
    const timerId = setInterval(checkFile, delay);
    checkFile();
  
    return timerId;
  };

// END
