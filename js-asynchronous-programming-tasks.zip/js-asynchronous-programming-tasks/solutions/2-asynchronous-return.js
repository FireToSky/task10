import fs from 'fs';

// BEGIN
export default function Func (path, data, callback) {
    fs.writeFile(path, data, (_err) => {callback(console.log('success'))})
}
// END