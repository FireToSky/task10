import path from 'path';
import fs from 'fs';
import _ from 'lodash';
import async from 'async';

// BEGIN
export const getDirectorySize = (directoryPath, callback) => {
    fs.readdir(directoryPath, (readError, files) => {
      if (readError) {
        callback(readError, null);
        return;
      }
  
      const filePaths = files.map((file) => path.join(directoryPath, file));
  
      async.map(
        filePaths,
        (filePath, asyncCallback) => {
          fs.stat(filePath, (statError, stats) => {
            if (statError) {
              asyncCallback(statError, null);
              return;
            }
  
            if (stats.isFile()) {
              asyncCallback(null, stats.size);
            } else {
              asyncCallback(null, 0);
            }
          });
        },
        (mapError, fileSizes) => {
          if (mapError) {
            callback(mapError, null);
            return;
          }
  
          const totalSize = _.sumBy(fileSizes);
          callback(null, totalSize);
        }
      );
    });
  };
// END
