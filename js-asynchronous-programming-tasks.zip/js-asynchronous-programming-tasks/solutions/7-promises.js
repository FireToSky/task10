import fsp from 'fs/promises';

// BEGIN
export const reverse = (filepath) => {
    return fsp.readFile(filepath, 'utf8')
      .then((data) => {
        const lines = data.trim().split('\n');
        const reversedLines = lines.reverse().join('\n');
        return fsp.writeFile(filepath, reversedLines);
      })
};
// END