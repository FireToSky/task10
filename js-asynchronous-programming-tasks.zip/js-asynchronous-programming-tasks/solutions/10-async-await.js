import fsp from 'fs/promises';

// BEGIN
export const exchange = async (file1, file2) => {
    const [data1, data2] = await Promise.all([
      fsp.readFile(file1, 'utf-8').catch(() => null),
      fsp.readFile(file2, 'utf-8').catch(() => null),
    ]);
  
    await Promise.all([
      fsp.writeFile(file1, data2, 'utf-8').catch(err => console.error('Error writing to', file1, err)),
      fsp.writeFile(file2, data1, 'utf-8').catch(err => console.error('Error writing to', file2, err)),
    ]);
  };
// END