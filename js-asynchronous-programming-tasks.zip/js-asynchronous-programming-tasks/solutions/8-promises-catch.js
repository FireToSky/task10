import fsp from 'fs/promises';

// BEGIN
export const touch = (path) => {
  return fsp.access(path, fsp.constants.F_OK)
    .then(() => console.log('already exists'))
    .catch(() => {
      return fsp.writeFile(path, '')
        .then(() => console.log('created'));
    });
};
// END